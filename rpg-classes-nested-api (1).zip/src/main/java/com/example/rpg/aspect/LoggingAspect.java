
package com.example.rpg.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

import java.util.Arrays;

@Aspect
@Component
public class LoggingAspect {

    @Before("@annotation(com.example.rpg.aspect.LogMethodParam)")
    public void logParams(JoinPoint joinPoint) {
        Object[] args = joinPoint.getArgs();
        System.out.println("Method: " + joinPoint.getSignature().getName() + ", Args: " + Arrays.toString(args));
    }
}
