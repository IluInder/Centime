
package com.example.rpg.controller;

import com.example.rpg.aspect.LogMethodParam;
import com.example.rpg.dto.ClassDTO;
import com.example.rpg.entity.CharacterClass;
import com.example.rpg.service.CharacterClassService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/classes")
public class ClassController {

    @Autowired
    private CharacterClassService service;

    @PostMapping("/populate")
    @LogMethodParam
    public String populate() {
        List<CharacterClass> data = List.of(
            new CharacterClass(1L, 0L, "Warrior", "red"),
            new CharacterClass(2L, 0L, "Wizard", "green"),
            new CharacterClass(3L, 0L, "Priest", "white"),
            new CharacterClass(4L, 0L, "Rogue", "yellow"),
            new CharacterClass(5L, 1L, "Fighter", "blue"),
            new CharacterClass(6L, 1L, "Paladin", "lighblue"),
            new CharacterClass(7L, 1L, "Ranger", "lighgreen"),
            new CharacterClass(8L, 2L, "Mage", "grey"),
            new CharacterClass(9L, 2L, "Specialist wizard", "lightgrey"),
            new CharacterClass(10L, 3L, "Cleric", "red"),
            new CharacterClass(11L, 3L, "Druid", "green"),
            new CharacterClass(12L, 3L, "Priest of specific mythos", "white"),
            new CharacterClass(13L, 4L, "Thief", "yellow"),
            new CharacterClass(14L, 4L, "Bard", "blue"),
            new CharacterClass(15L, 13L, "Assassin", "lighblue")
        );
        service.saveAll(data);
        return "Database populated!";
    }

    @GetMapping("/{id}")
    @LogMethodParam
    public ResponseEntity<CharacterClass> getById(@PathVariable Long id) {
        return service.getById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping
    public List<ClassDTO> getAllNested() {
        return service.getNestedClasses();
    }
}
