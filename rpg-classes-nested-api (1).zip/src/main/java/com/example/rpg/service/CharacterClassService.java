
package com.example.rpg.service;

import com.example.rpg.dto.ClassDTO;
import com.example.rpg.entity.CharacterClass;
import com.example.rpg.repository.CharacterClassRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class CharacterClassService {

    @Autowired
    private CharacterClassRepository repo;

    public void saveAll(List<CharacterClass> classes) {
        repo.saveAll(classes);
    }

    public Optional<CharacterClass> getById(Long id) {
        return repo.findById(id);
    }

    public List<ClassDTO> getNestedClasses() {
        List<CharacterClass> all = repo.findAll();
        Map<Long, ClassDTO> map = new HashMap<>();

        for (CharacterClass cc : all) {
            map.put(cc.getId(), new ClassDTO(cc.getName()));
        }

        for (CharacterClass cc : all) {
            if (cc.getParentId() != 0) {
                ClassDTO parent = map.get(cc.getParentId());
                if (parent != null) {
                    parent.getSubClasses().add(map.get(cc.getId()));
                }
            }
        }

        return all.stream()
                .filter(cc -> cc.getParentId() == 0)
                .map(cc -> map.get(cc.getId()))
                .collect(Collectors.toList());
    }
}
