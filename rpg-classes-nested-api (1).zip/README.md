# RPG Classes Nested API

A Spring Boot REST API that:
- Hosts a nested class structure for RPG character types.
- Uses H2 in-memory DB and auto-creates schema.
- Exposes REST endpoints to populate and fetch data.
- Demonstrates parent-child mapping manually (no ORM mapping).

## ✅ API Endpoints

### ▶️ Populate Data
`POST /classes/populate`

### 📥 Get by ID
`GET /classes/{id}`

### 🌳 Get All Nested
`GET /classes`

## ✅ Run Locally
```bash
mvn spring-boot:run
```

## ✅ Test H2 Console
Visit: `http://localhost:8080/h2-console`  
JDBC URL: `jdbc:h2:mem:testdb`

## ✅ Custom Logging
Logs method parameters using custom annotation: `@LogMethodParam`

## License
MIT
