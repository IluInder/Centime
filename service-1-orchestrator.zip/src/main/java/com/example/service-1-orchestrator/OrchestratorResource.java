
package com.example.service1;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.*;
import java.util.UUID;
import java.util.logging.Logger;

@Path("/")
public class OrchestratorResource {
    private static final Logger logger = Logger.getLogger(OrchestratorResource.class.getName());

    @GET
    @Path("/status")
    @Produces(MediaType.TEXT_PLAIN)
    public String getStatus() {
        String traceId = UUID.randomUUID().toString();
        logger.info("TraceID=" + traceId + " - Status check called");
        return "Up";
    }

    @POST
    @Path("/orchestrate")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response orchestrate(String json) {
        String traceId = UUID.randomUUID().toString();
        logger.info("TraceID=" + traceId + " - Orchestrate POST called with input: " + json);

        try {
            String hello = "Hello"; // Mocked call to service 2
            String name = "John Doe"; // Mocked call to service 3

            String result = hello + " " + name;
            return Response.ok("{\"message\": \"" + result + "\"}").build();
        } catch (Exception e) {
            logger.severe("TraceID=" + traceId + " - Error: " + e.getMessage());
            return Response.serverError().entity("{\"error\": \"Internal error\"}").build();
        }
    }
}
