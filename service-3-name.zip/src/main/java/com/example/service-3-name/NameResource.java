
package com.example.service3;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.*;
import java.io.StringReader;
import java.util.logging.Logger;
import jakarta.json.*;

@Path("/name")
public class NameResource {
    private static final Logger logger = Logger.getLogger(NameResource.class.getName());

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.TEXT_PLAIN)
    public Response getFullName(String json, @HeaderParam("TraceID") String traceId) {
        logger.info("TraceID=" + traceId + " - POST /name called with input: " + json);
        try (JsonReader reader = Json.createReader(new StringReader(json))) {
            JsonObject obj = reader.readObject();
            String name = obj.getString("Name");
            String surname = obj.getString("Surname");
            return Response.ok(name + " " + surname).build();
        } catch (Exception e) {
            logger.severe("TraceID=" + traceId + " - Invalid JSON: " + e.getMessage());
            return Response.status(Response.Status.BAD_REQUEST)
                .entity("Invalid JSON: expected fields 'Name' and 'Surname'").build();
        }
    }
}
