# service-2-hello

This is the service-2-hello microservice.
