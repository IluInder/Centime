
package com.example.service2;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.*;
import java.util.logging.Logger;

@Path("/message")
public class MessageResource {
    private static final Logger logger = Logger.getLogger(MessageResource.class.getName());

    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public Response getMessage(@HeaderParam("TraceID") String traceId) {
        logger.info("TraceID=" + traceId + " - GET /message called");
        return Response.ok("Hello").build();
    }
}
